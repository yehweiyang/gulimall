package springbootjsp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {


    @RequestMapping(path="/",method=RequestMethod.GET)
    public String home(){
        return "index";
    }

    @RequestMapping(path="/query",method=RequestMethod.POST)
    @ResponseBody
    public List<Record> query(Model model){
        List<Record> recordings = new ArrayList<>();
        recordings.add(new Record("20230016963", "123456789", "00003153819318", "12345", "0222811313"));
        recordings.add(new Record("20240016963", "10102230443", "66603153819318", "54321", "09122811313"));

        model.addAttribute("records", recordings);

        return recordings;
    }

    @RequestMapping(path="/download",method=RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> download(@RequestBody TransactionRequest request){

        return ResponseEntity.ok("成功接收交易編號");
    }


}
